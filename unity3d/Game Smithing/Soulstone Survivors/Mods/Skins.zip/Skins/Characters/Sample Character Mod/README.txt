This folder contains template files you can use to get started.

There is a Character_Skin_Icon_Background_Template.png file which you can use as the background for you character icon. Just open it on your preferred image editing software (could even be MS Paint) and place your icon atop of the Template, save it and edit the metadata.json file accordingly.
If you prefer using Photoshop, there's a Character_Skin_Icon_Template.psd file which you can use to build your character icon.

Follow our character guide for more info: https://mod.io/g/soulstonesurvivors/r/creating-a-character-skin