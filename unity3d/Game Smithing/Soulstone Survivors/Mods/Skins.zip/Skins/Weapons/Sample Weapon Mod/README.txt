This folder contains template files you can use to get started.

There are several image files named *_Template.png which you can use (pick your favourite one) as the background for you weapon icon. Just open it on your preferred image editing software (could even be MS Paint) and place your icon atop of the template, save it and edit the metadata.json file accordingly.
If you prefer using Photoshop, there's a Weapon_Icon_Template.psd file which you can use to build your weapon icon.

Follow our Weapon guide for more info: https://mod.io/g/soulstonesurvivors/r/creating-a-weapon-skin 